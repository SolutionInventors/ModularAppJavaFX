
-- --------------------------------------------------------

--
-- Table structure for table `module`
--

CREATE TABLE `module` (
  `dateCreated` date DEFAULT NULL,
  `name` varchar(100) COLLATE latin1_bin NOT NULL,
  `units` int(11) NOT NULL,
  `amountPerUnit` double NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

--
-- Dumping data for table `module`
--

INSERT INTO `module` (`dateCreated`, `name`, `units`, `amountPerUnit`) VALUES
('2017-12-19', 'Electrical Installation', 10, 3000),
('2018-02-09', 'Electrical Load', 10, 3000),
('2018-02-09', 'Electrical Panel', 10, 20000),
('2018-02-13', 'Fundamentals of engines', 10, 2000),
('2018-02-09', 'Knx', 20, 1000),
('2018-02-13', 'Mechanical Mesurements and fitting', 10, 20),
('2017-12-19', 'Motor Controls', 10, 3000),
('2018-02-09', 'Name', 30, 203203),
('2018-02-13', 'Physics', 10, 2000),
('2018-02-13', 'Power electronics', 10, 20),
('2018-02-13', 'Technical Drawing', 10, 2000);

--
-- Triggers `module`
--
DELIMITER $$
CREATE TRIGGER `moduleDeleteTrigger` AFTER DELETE ON `module` FOR EACH ROW BEGIN
	INSERT INTO ModuleLog( dateOfOperation, operationType, oldModuleName , newModuleName)
    VALUES( now(), 'DELETE', old.name, NULL);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `moduleInsertTrigger` AFTER INSERT ON `module` FOR EACH ROW BEGIN
	INSERT INTO ModuleLog( dateOfOperation, operationType, oldModuleName, newModuleName)
    VALUES( now(), 'INSERT', NULL , new.name);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `moduleUpdateTrigger` AFTER UPDATE ON `module` FOR EACH ROW BEGIN
	INSERT INTO ModuleLog( dateOfOperation, operationType, oldModuleName, newModuleName)
    VALUES( now(), 'UPDATE', old.name, new.name);
END
$$
DELIMITER ;
