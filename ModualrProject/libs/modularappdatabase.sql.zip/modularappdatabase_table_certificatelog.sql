
-- --------------------------------------------------------

--
-- Table structure for table `certificatelog`
--

CREATE TABLE `certificatelog` (
  `dateOfOperation` date DEFAULT NULL,
  `operationType` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `oldCertificateName` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `newCertificateName` varchar(100) COLLATE latin1_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

--
-- Dumping data for table `certificatelog`
--

INSERT INTO `certificatelog` (`dateOfOperation`, `operationType`, `oldCertificateName`, `newCertificateName`) VALUES
('2017-12-19', 'DELETE', 'Modular', NULL),
('2017-12-19', 'DELETE', 'Modular Electrotechnics', NULL),
('2017-12-19', 'UPDATE', 'Modular Electromecnics', 'Electromecnics'),
('2017-12-19', 'INSERT', NULL, 'Modular'),
('2017-12-19', 'INSERT', NULL, 'Modular Electromecnics'),
('2017-12-19', 'INSERT', NULL, 'Modular Electrotechnics'),
('2017-12-19', 'INSERT', NULL, 'Modular Electrotechnics'),
('2017-12-19', 'INSERT', NULL, 'Modular Mecatronics'),
('2017-12-22', 'DELETE', 'Bew', NULL),
('2017-12-22', 'DELETE', 'New', NULL),
('2017-12-22', 'DELETE', 'Newcert', NULL),
('2017-12-22', 'DELETE', 'Newcert', NULL),
('2017-12-22', 'DELETE', 'Newcert', NULL),
('2017-12-22', 'INSERT', NULL, 'Bew'),
('2017-12-22', 'INSERT', NULL, 'Junk'),
('2017-12-22', 'INSERT', NULL, 'Name'),
('2017-12-22', 'INSERT', NULL, 'New'),
('2017-12-22', 'INSERT', NULL, 'Newcert'),
('2017-12-22', 'INSERT', NULL, 'Newcert'),
('2017-12-22', 'INSERT', NULL, 'Newcert');
