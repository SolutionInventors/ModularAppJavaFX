
-- --------------------------------------------------------

--
-- Table structure for table `aspiringstudentphone`
--

CREATE TABLE `aspiringstudentphone` (
  `AspiringID` int(255) NOT NULL,
  `AspiringPhone` varchar(30) COLLATE latin1_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;
