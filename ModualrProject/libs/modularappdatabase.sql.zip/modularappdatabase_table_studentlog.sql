
-- --------------------------------------------------------

--
-- Table structure for table `studentlog`
--

CREATE TABLE `studentlog` (
  `dateOfOperation` date DEFAULT NULL,
  `operationType` varchar(10) COLLATE latin1_bin DEFAULT NULL,
  `OldID` varchar(50) COLLATE latin1_bin DEFAULT NULL,
  `NewID` varchar(50) COLLATE latin1_bin DEFAULT NULL,
  `PrevCertificateIssued` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `NewCertificateIssued` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `PrevActiveStatus` tinyint(1) DEFAULT NULL,
  `NewActiveStatus` tinyint(1) DEFAULT NULL,
  `PrevEmail` varchar(256) COLLATE latin1_bin DEFAULT NULL,
  `NewEmail` varchar(256) COLLATE latin1_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

--
-- Dumping data for table `studentlog`
--

INSERT INTO `studentlog` (`dateOfOperation`, `operationType`, `OldID`, `NewID`, `PrevCertificateIssued`, `NewCertificateIssued`, `PrevActiveStatus`, `NewActiveStatus`, `PrevEmail`, `NewEmail`) VALUES
('2017-12-19', 'UPDATE', NULL, 'EMY-C4', '', NULL, NULL, 1, NULL, 'email@email.com'),
('2017-12-19', 'UPDATE', NULL, 'ETY-C3', '', NULL, NULL, 1, NULL, 'email@email.com'),
('2017-12-21', 'UPDATE', NULL, 'EMY-C32', '', NULL, NULL, 1, NULL, 'email@email.com'),
('2018-02-06', 'UPDATE', NULL, 'EMUAIDA', '', NULL, NULL, 1, NULL, 'email@email.com'),
('2018-02-06', 'UPDATE', NULL, 'EMY-CDASCA', '', NULL, NULL, 1, NULL, 'email@email.com'),
('2018-02-09', 'UPDATE', 'EMY-C32', 'EMY-C32', NULL, NULL, 1, 1, 'email@email.com', 'email@email.com'),
('2018-02-09', 'UPDATE', 'EMY-C32', 'EMY-C32', NULL, NULL, 1, 1, 'email@email.com', 'email@email.com'),
('2018-02-09', 'UPDATE', NULL, 'EMY-C4340', '', NULL, NULL, 1, NULL, 'email@email.com'),
('2018-02-09', 'UPDATE', NULL, 'EMY-C54', '', NULL, NULL, 1, NULL, 'email@email.com'),
('2018-02-09', 'UPDATE', NULL, 'ETY-C43', '', NULL, NULL, 1, NULL, 'email@email.com'),
('2018-02-09', 'UPDATE', NULL, 'MINUS', '', NULL, NULL, 1, NULL, 'email@email.com'),
('2018-02-09', 'UPDATE', NULL, 'NAME', '', NULL, NULL, 1, NULL, 'email@email.com'),
('2018-02-12', 'UPDATE', 'EMY-C32', 'EMY-C32', NULL, 'Modular Mecatronics', 1, 1, 'email@email.com', 'email@email.com'),
('2018-02-12', 'UPDATE', NULL, 'Fred1010', NULL, NULL, NULL, 1, NULL, 'email@email.com'),
('2018-02-12', 'UPDATE', NULL, 'PIO2828', NULL, NULL, NULL, 1, NULL, 'email@email.com'),
('2018-02-13', 'UPDATE', 'EMY-C4340', 'EMY-C$', NULL, NULL, 1, 1, 'email@email.com', 'email@email.com'),
('2018-02-13', 'UPDATE', 'EMY-CDASCA', 'EMY-C1', NULL, NULL, 1, 1, 'email@email.com', 'email@email.com'),
('2018-02-13', 'UPDATE', 'EMY-C$', 'EMY-C4', NULL, NULL, 1, 1, 'email@email.com', 'email@email.com'),
('2018-02-13', 'UPDATE', 'ETY-C43', 'ETY-C3', NULL, NULL, 1, 1, 'email@email.com', 'email@email.com'),
('2018-02-13', 'UPDATE', 'Fred1010', 'FRED1010', NULL, NULL, 1, 1, 'email@email.com', 'email@email.com');
