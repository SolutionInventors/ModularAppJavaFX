
-- --------------------------------------------------------

--
-- Table structure for table `aspiringmeans`
--

CREATE TABLE `aspiringmeans` (
  `AspiringID` int(255) NOT NULL,
  `Means` varchar(255) COLLATE latin1_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;
