
-- --------------------------------------------------------

--
-- Table structure for table `aspiringjobresponsibility`
--

CREATE TABLE `aspiringjobresponsibility` (
  `AspiringExpId` int(255) NOT NULL,
  `Duty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;
