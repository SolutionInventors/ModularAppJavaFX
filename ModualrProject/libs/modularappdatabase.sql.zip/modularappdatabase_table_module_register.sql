
-- --------------------------------------------------------

--
-- Table structure for table `module_register`
--

CREATE TABLE `module_register` (
  `id` int(11) NOT NULL,
  `DateRegistered` date NOT NULL,
  `ModuleName` varchar(100) COLLATE latin1_bin NOT NULL,
  `StudentId` varchar(50) COLLATE latin1_bin NOT NULL,
  `totalPriceForModule` double NOT NULL,
  `AttendanceStatus` tinyint(1) NOT NULL,
  `BookingStatus` tinyint(1) NOT NULL,
  `Result` set('PASS','FAIL') COLLATE latin1_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

--
-- Dumping data for table `module_register`
--

INSERT INTO `module_register` (`id`, `DateRegistered`, `ModuleName`, `StudentId`, `totalPriceForModule`, `AttendanceStatus`, `BookingStatus`, `Result`) VALUES
(4, '2017-12-21', 'Motor Controls', 'EMY-C32', 30000, 1, 1, 'FAIL'),
(5, '2017-12-22', 'Electrical Installation', 'EMY-C32', 30000, 0, 1, NULL),
(6, '2017-12-22', 'Electrical Installation', 'EMY-C32', 30000, 0, 0, NULL),
(9, '2018-02-09', 'Motor Controls', 'EMUAIDA', 30000, 0, 0, 'FAIL'),
(10, '2018-02-09', 'Motor Controls', 'EMUAIDA', 30000, 0, 0, NULL),
(11, '2018-02-09', 'Motor Controls', 'ETY-C3', 30000, 0, 0, NULL),
(12, '2018-02-13', 'Electrical Load', 'EMUAIDA', 30000, 0, 0, NULL),
(13, '2018-02-13', 'Electrical Panel', 'EMUAIDA', 200000, 0, 0, NULL),
(14, '2018-02-13', 'Electrical Panel', 'EMY-C54', 200000, 0, 1, NULL),
(15, '2018-02-13', 'Knx', 'EMY-C54', 20000, 0, 0, NULL),
(16, '2018-02-13', 'Knx', 'MINUS', 20000, 1, 1, 'FAIL'),
(17, '2018-02-13', 'Knx', 'NAME', 20000, 0, 1, NULL),
(18, '2018-02-13', 'Electrical Load', 'PIO2828', 30000, 0, 0, NULL),
(19, '2018-02-13', 'Knx', 'EMY-C4', 20000, 0, 0, NULL),
(20, '2018-02-13', 'Electrical Panel', 'EMY-C4', 200000, 0, 0, NULL);

--
-- Triggers `module_register`
--
DELIMITER $$
CREATE TRIGGER `moduleRegisterInsertTrigger` AFTER INSERT ON `module_register` FOR EACH ROW BEGIN
INSERT INTO `moduleregisterlog`(`regId`, `operationType`, `DateOfOperation`, `StudentId`, `OldModuleName`, `NewModuleName`, `OldAttendanceStatus`, `NewAttendanceStatus`, `OldBookingStatus`, `NewBookingStatus`, `OldResult`, `NewResult`)
VALUES (new.Id,'INSERT', NOW() , new.studentId,
  NULL ,new.moduleName,NULL ,new.attendanceStatus,NULL ,
        new.bookingStatus,NULL ,new.result);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `moduleRegisterUpdateTrigger` AFTER UPDATE ON `module_register` FOR EACH ROW BEGIN
INSERT INTO `moduleregisterlog`(`regId`, `operationType`, `DateOfOperation`, `StudentId`, `OldModuleName`, `NewModuleName`, `OldAttendanceStatus`, `NewAttendanceStatus`, `OldBookingStatus`, `NewBookingStatus`, `OldResult`, `NewResult`)
VALUES (new.Id,'INSERT', NOW() , new.studentId,
  old.moduleName ,new.moduleName,
        old.attendanceStatus ,new.attendanceStatus,
        old.bookingStatus ,
        new.bookingStatus,old.result ,new.result);
END
$$
DELIMITER ;
