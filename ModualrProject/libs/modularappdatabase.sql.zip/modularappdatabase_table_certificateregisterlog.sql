
-- --------------------------------------------------------

--
-- Table structure for table `certificateregisterlog`
--

CREATE TABLE `certificateregisterlog` (
  `DateOfOperation` date DEFAULT NULL,
  `operationType` set('INSERT','UPDATE','DELETE') COLLATE latin1_bin DEFAULT NULL,
  `NewModuleName` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `NewCertificateName` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `OldModuleName` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `OldCertificateName` varchar(100) COLLATE latin1_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

--
-- Dumping data for table `certificateregisterlog`
--

INSERT INTO `certificateregisterlog` (`DateOfOperation`, `operationType`, `NewModuleName`, `NewCertificateName`, `OldModuleName`, `OldCertificateName`) VALUES
('2017-12-19', 'INSERT', 'Motor Controls', 'Electromecnics', NULL, NULL),
('2017-12-19', 'DELETE', NULL, NULL, 'Motor Controls', 'Electromecnics'),
('2018-02-13', 'INSERT', 'Electrical Installation', 'Electromecnics', NULL, NULL),
('2018-02-13', 'INSERT', 'Electrical Panel', 'Electromecnics', NULL, NULL),
('2018-02-13', 'INSERT', 'Motor Controls', 'Electromecnics', NULL, NULL),
('2018-03-07', 'INSERT', 'Mechanical Mesurements and fitting', 'Electromecnics', NULL, NULL),
('2018-03-07', 'INSERT', 'Physics', 'Electromecnics', NULL, NULL),
('2018-03-07', 'INSERT', 'Electrical Installation', 'Modular Mecatronics', NULL, NULL),
('2018-03-07', 'INSERT', 'Motor Controls', 'Modular Mecatronics', NULL, NULL),
('2018-03-07', 'INSERT', 'Power electronics', 'Modular Mecatronics', NULL, NULL),
('2018-03-07', 'INSERT', 'Technical Drawing', 'Modular Mecatronics', NULL, NULL),
('2018-03-07', 'INSERT', 'Electrical Installation', 'Name', NULL, NULL),
('2018-03-07', 'INSERT', 'Mechanical Mesurements and fitting', 'Name', NULL, NULL),
('2018-03-07', 'INSERT', 'Physics', 'Name', NULL, NULL),
('2018-03-07', 'INSERT', 'Power electronics', 'Name', NULL, NULL),
('2018-03-07', 'DELETE', NULL, NULL, 'Electrical Installation', 'Electromecnics'),
('2018-03-07', 'DELETE', NULL, NULL, 'Motor Controls', 'Electromecnics');
