
-- --------------------------------------------------------

--
-- Table structure for table `professional_experience`
--

CREATE TABLE `professional_experience` (
  `id` int(11) NOT NULL,
  `StudentId` varchar(50) COLLATE latin1_bin NOT NULL,
  `Employer` varchar(200) COLLATE latin1_bin NOT NULL,
  `Job Title` varchar(200) COLLATE latin1_bin NOT NULL,
  `StartDate` date NOT NULL,
  `EndDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

--
-- Dumping data for table `professional_experience`
--

INSERT INTO `professional_experience` (`id`, `StudentId`, `Employer`, `Job Title`, `StartDate`, `EndDate`) VALUES
(13, 'EMY-C32', 'Cadbury', 'Manager', '2000-01-10', '2009-01-10'),
(12, 'EMY-C32', 'Cummins', 'Intern', '2000-01-10', '2009-01-10'),
(15, 'EMY-C54', 'Cadbury', 'Intern', '2000-01-10', '2009-01-10'),
(14, 'EMY-C54', 'Cummins', 'Intern', '2000-01-10', '2009-01-10');
