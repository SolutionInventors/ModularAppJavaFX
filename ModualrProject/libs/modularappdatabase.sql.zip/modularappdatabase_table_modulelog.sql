
-- --------------------------------------------------------

--
-- Table structure for table `modulelog`
--

CREATE TABLE `modulelog` (
  `dateOfOperation` date DEFAULT NULL,
  `oldModuleName` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `newModuleName` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `operationType` varchar(20) COLLATE latin1_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

--
-- Dumping data for table `modulelog`
--

INSERT INTO `modulelog` (`dateOfOperation`, `oldModuleName`, `newModuleName`, `operationType`) VALUES
('2017-12-19', 'cdcd', NULL, 'DELETE'),
('2017-12-19', NULL, 'Electrical Installation', 'INSERT'),
('2017-12-19', NULL, 'Electrical Installation', 'INSERT'),
('2017-12-19', NULL, 'cdcd', 'INSERT'),
('2017-12-19', 'Electrical Installation', 'Motor Controls', 'UPDATE'),
('2018-02-09', NULL, 'Electrical Load', 'INSERT'),
('2018-02-09', NULL, 'Electrical Panel', 'INSERT'),
('2018-02-09', NULL, 'KNX', 'INSERT'),
('2018-02-09', NULL, 'Name', 'INSERT'),
('2018-02-13', NULL, 'Fundamentals of engines', 'INSERT'),
('2018-02-13', NULL, 'Mechanical Mesurements and fitting', 'INSERT'),
('2018-02-13', NULL, 'Physics', 'INSERT'),
('2018-02-13', NULL, 'Power electronics', 'INSERT'),
('2018-02-13', NULL, 'Technical Drawing', 'INSERT'),
('2018-02-13', 'KNX', 'Knx', 'UPDATE');
