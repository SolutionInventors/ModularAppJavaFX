
-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id` int(11) NOT NULL,
  `RegId` int(11) DEFAULT NULL,
  `amount` double NOT NULL,
  `bankName` varchar(200) COLLATE latin1_bin DEFAULT NULL,
  `tellerNumber` int(20) DEFAULT NULL,
  `dateOfPayment` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `RegId`, `amount`, `bankName`, `tellerNumber`, `dateOfPayment`) VALUES
(2, 4, 2000, 'Oceanic', 1234556, '2009-01-10'),
(4, 4, 2000, 'Oceanic', 1023232, '2010-01-10'),
(5, 4, 20000, 'Oceanic', 123940303, '2010-01-10'),
(6, 4, 5000, 'Oceanic', 129109210, '2010-01-10'),
(7, 4, 1000, 'Oceanic', 2120120101, '2010-01-10'),
(8, 6, 2000, 'Oceanic', 12345678, '2010-01-10'),
(9, 6, 3000, 'Gtb', 123455678, '2010-01-10');

--
-- Triggers `payment`
--
DELIMITER $$
CREATE TRIGGER `payementInsertTrigger` AFTER INSERT ON `payment` FOR EACH ROW BEGIN

SELECT reg.ModuleName, reg.StudentId 
	FROM module_register as reg 
WHERE reg.id = new.regId 
into @modName, @studID;

 INSERT INTO PaymentLog
  ( regId, dateofoperation, operationType,BankName,  amount, paymentlog.StudentID, paymentlog.ModuleName)
 VALUES( new.regId, now(), 'INSERT',new.bankName,new.amount, @studID,@modName   );
END
$$
DELIMITER ;
