
DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `addEducationRecord` (IN `studId` VARCHAR(50), IN `begin` DATE, IN `end` DATE, IN `institute` VARCHAR(200), IN `course` VARCHAR(200), IN `qualification` VARCHAR(200))  BEGIN

INSERT INTO `educational_background`(`StudentId`, `BeginDate`, `EndDate`, `Institution`, `CourseRead`, `QualificationName`) 
VALUES (
 studId,begin,end,institute,course,qualification);

End$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `addExperienceRecord` (IN `studId` VARCHAR(50), IN `beginDate` DATE, IN `endDate` DATE, IN `employer` VARCHAR(200), IN `jobName` VARCHAR(200), OUT `generated` INT)  BEGIN


INSERT INTO `professional_experience`(`StudentId`, `StartDate`, `EndDate`, `Employer`, `Job Title`)
VALUES( studId,beginDate,endDate,employer,jobName);

SELECT MAX(id) FROM professional_experience 
	INTO generated;
End$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `addMeansOfDiscovery` (IN `studId` VARCHAR(50), IN `means` VARCHAR(300))  BEGIN
INSERT INTO `means_of_discovery`(`StudentID`, `Means`) 
VALUES (studId,means );

end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `addModToCert` (IN `certName` VARCHAR(200), IN `modName` VARCHAR(100))  BEGIN
INSERT INTO `certificateRegister`(`certificateName`, `moduleName`) 
VALUES ( TRIM(certName), TRIM(modName) );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `addPhoneNumber` (IN `studId` VARCHAR(50), IN `number` VARCHAR(20))  BEGIN 
INSERT INTO `phone`(`StudentId`, `phone_number`) 
VALUES (studId, number );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `addResponsibity` (IN `expId` INT, IN `res` VARCHAR(1000), OUT `theId` INT)  NO SQL
BEGIN
INSERT INTO responsibilty(ExperienceId, Duty)
VALUES( expId, res);

SELECT id FROM responsibilty WHERE
	responsibilty.experienceId = expId AND
    responsibilty.Duty = res INTO  theId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `addSponsor` (IN `studId` VARCHAR(50), IN `fName` VARCHAR(30), IN `lName` VARCHAR(30), IN `addr` VARCHAR(200), IN `phone` VARCHAR(20), IN `mail` VARCHAR(100))  BEGIN
INSERT INTO `sponsor`(`StudentID`, `FirstName`, `LastName`, `Address`, `Telephone`, `Email`) 
VALUES (studId,fName,lName,addr,phone, mail);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `attendModule` (IN `regId` INT, IN `studId` VARCHAR(50), IN `modName` VARCHAR(100))  NO SQL
BEGIN

UPDATE module_register as reg 
	SET reg.AttendanceStatus = true
    WHERE reg.ModuleName = modName AND reg.StudentId= studId AND reg.id = regId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `bookModule` (IN `regId` INT, IN `studId` VARCHAR(50), IN `modName` VARCHAR(100))  NO SQL
BEGIN

UPDATE module_register reg 
	SET reg.BookingStatus = true
    WHERE reg.StudentId = studId AND reg.ModuleName = modName AND reg.id = regId;
    
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `createCertificate` (IN `certName` VARCHAR(200), OUT `dateCreated` INT)  BEGIN
Set @dateCreated = now();

INSERT INTO `certificate`
( `dateCreated`, `name`) 
VALUES ( @dateCreated , TRIM(certName));
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `createNewClass` (IN `name` VARCHAR(30), OUT `creationDate` DATE)  BEGIN
set creationDate = now();

INSERT INTO `modular_class`(`name`, `dateCreated`)
VALUES (name ,creationDate);
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `createNewModule` (IN `modName` VARCHAR(100), IN `numOfUnits` INT, IN `price` DOUBLE, OUT `creationDate` DATE)  BEGIN
set creationDate = NOW();
INSERT INTO `module`(`dateCreated`, `name`, `units`, `amountPerUnit`) 
VALUES (creationDate,modName,numOfUnits,price);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `deleteCertificate` (IN `certName` VARCHAR(200))  BEGIN 
    DELETE FROM `certificate` WHERE `name` = certName;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertAdmin` (IN `uName` VARCHAR(200), IN `pass` VARCHAR(500), IN `mail` VARCHAR(256))  NO SQL
BEGIN
INSERT into admin( username, password, Email)
VALUES( uName, pass, mail);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertBiodata` (IN `studId` VARCHAR(50), IN `title` VARCHAR(10), IN `permanentAddr` VARCHAR(1000), IN `currentAddr` VARCHAR(1000), IN `religion` VARCHAR(100), IN `state` VARCHAR(100), IN `country` VARCHAR(100), IN `gender` VARCHAR(6), IN `birthDate` DATE, IN `placeOfBirth` VARCHAR(100))  NO SQL
BEGIN
INSERT into biodata( studentId, Title,  PermanentAddress, CurrentAddress, Religion, stateOfOrigin, country, gender, dateOfBirth, placeOfBirth)

VALUES( studId, title, permanentAddr,  currentAddr ,religion,state, country, gender, birthDate,   placeOfBirth);

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertDuty` (IN `expId` INT, IN `inDuty` VARCHAR(1000), OUT `theId` INT)  NO SQL
BEGIN
INSERT into responsibilty( duty, experienceId)
VALUES(inDuty, expId );

SELECT id FROM responsibilty WHERE
	duty = inDuty AND experienceId= expId
    INTO theId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertStudent` (IN `cardNum` VARCHAR(50), IN `mail` VARCHAR(254), IN `img` LONGBLOB, IN `class` VARCHAR(30), IN `fName` VARCHAR(50), IN `lName` VARCHAR(50), OUT `regDate` DATE)  BEGIN
SELECT now() into regDate;
INSERT INTO `student`(`id_card_number`, `dateAdmitted`, `active`, `emailAddress`, `className`, `image`, `FirstName`, `LastName`)
VALUES (cardNum ,regDate,true,mail,class,img, fName, lName);
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `makePayment` (IN `modRegisterId` INT, IN `amountPaid` DOUBLE, IN `bankName` VARCHAR(200), IN `tellerNumber` INT(20), IN `paymentDate` DATE)  BEGIN

INSERT INTO `payment`( `RegId`, `amount`, `bankName`, `tellerNumber`, `dateOfPayment`) 
VALUES (modRegisterId ,amountPaid,bankName,tellerNumber,paymentDate );

end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `registerForModule` (IN `studId` VARCHAR(50), IN `modName` VARCHAR(100), OUT `regDate` DATE)  BEGIN
set regDate = now();

SELECT module.units * module.amountPerUnit 
FROM module  
WHERE module.name = modName 
INTO @price;


INSERT INTO `module_register`( `dateRegistered`, `moduleName`, `AttendanceStatus`, `studentId`, `bookingStatus`, `totalPriceForModule`, `result`)
VALUES (regDate,modName,false,studId,false, @price
        ,null );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `removeAdmin` (IN `uName` VARCHAR(200))  NO SQL
BEGIN
DELETE FROM admin WHERE admin.username = uName; 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `removeCertificate` (IN `certName` VARCHAR(200))  BEGIN
DELETE FROM `certificate` 
WHERE certificate.name = certName;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `removeClass` (IN `name` VARCHAR(30))  BEGIN
DELETE FROM `Modular_class`
	WHERE `Modular_class`.name =  TRIM(name) ;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `removeModFromCert` (IN `certName` VARCHAR(100), IN `modName` VARCHAR(100))  BEGIN
DELETE FROM `certificateRegister`
WHERE `certificateName` = certName AND `moduleName` = modName ; 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `removeModule` (IN `moduleName` VARCHAR(100))  BEGIN 
DELETE FROM `module` WHERE module.name = moduleName;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `removePhoneNumber` (IN `studId` VARCHAR(50), IN `number` VARCHAR(20))  BEGIN 
DELETE FROM phone  
	WHERE phone.student_id = studId AND phone.phone_number = number;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `removeStudent` (IN `id` VARCHAR(50))  BEGIN
DELETE FROM student WHERE id_card_number =  id;
 END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `setResult` (IN `modRegId` INT, IN `studId` VARCHAR(50), IN `modName` VARCHAR(100), IN `result` VARCHAR(4))  NO SQL
BEGIN
UPDATE module_register as reg 
	SET reg.Result = ucase(result) 
    WHERE reg.id = modRegId AND reg.StudentId = studId AND reg.ModuleName = modName;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updateAdmin` (IN `oldUsername` VARCHAR(200), IN `newUsername` VARCHAR(200), IN `newPass` VARCHAR(500))  BEGIN 
UPDATE `admin`
SET `username`=TRIM(newUsername) ,`password`=newPass 
	WHERE username = oldUsername ;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updateAdminMail` (IN `uName` VARCHAR(200), IN `mail` VARCHAR(256))  BEGIN
UPDATE `admin` SET `Email`= mail
WHERE username = uName;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updateAdminUsername` (IN `exstingUsername` VARCHAR(200), IN `newUname` VARCHAR(256))  NO SQL
BEGIN
UPDATE admin SET username  = newUname
WHERE username =  exstingUsername ;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updateBiodata` (IN `studId` VARCHAR(50), IN `title` VARCHAR(10), IN `surname` VARCHAR(50), IN `midName` VARCHAR(50), IN `lastName` VARCHAR(50), IN `permanentAddr` VARCHAR(1000), IN `currentAddr` VARCHAR(1000), IN `religion` VARCHAR(100), IN `state` VARCHAR(100), IN `country` VARCHAR(100), IN `gender` VARCHAR(6), IN `birthDate` DATE, IN `placeOfBirth` VARCHAR(100))  BEGIN
UPDATE biodata SET Title= title, Surname =surname,MiddleName = midName, LastName =lastName, PermanentAddress= permanentAddr, CurrentAddress = currentAddr, Religion = religion, stateOfOrigin = state, country = country, gender = gender, dateOfBirth = birthDate, placeOfBirth =placeOfBirth
WHERE  studentId = studId ;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updateCertificate` (IN `oldCertName` VARCHAR(200), IN `newName` VARCHAR(200))  BEGIN
UPDATE `certificate` 
SET `name`= TRIM(newName) WHERE oldCertName = `name` ;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updateClass` (IN `oldClassName` VARCHAR(100), IN `newClassName` VARCHAR(100), OUT `creationDate` DATE)  BEGIN
update Modular_class as class SET class.name = newClassName
WHERE class.name = oldClassName;
SELECT class.dateCreated from Modular_class as class
	WHERE class.name = newClassName into @date;
SET creationDate = @date;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updateDiscoveryRecord` (IN `studID` VARCHAR(50), IN `newMeans` VARCHAR(300), IN `oldMeans` VARCHAR(300))  NO SQL
BEGIN

UPDATE means_of_discovery
	SET `Means` = newMeans
    where StudentID = studId AND Means = oldMeans;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updateEducationRecord` (IN `studId` VARCHAR(50), IN `institute` VARCHAR(200), IN `beginDate` DATE, IN `endDate` DATE, IN `course` VARCHAR(200), IN `oldStudId` VARCHAR(50), IN `oldInst` VARCHAR(200), IN `oldBegin` DATE, IN `oldEnd` DATE, IN `oldCourse` VARCHAR(200))  NO SQL
UPDATE educational_background 
 SET StudentId = studId , Institution = institute  , BeginDate = beginDate, EndDate = endDate, CourseRead = course 
WHERE StudentId = oldStudId  AND Institution = oldInst AND BeginDate = oldBegin AND 
			+ 	EndDate = oldEnd AND  CourseRead = oldCourse$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updateMail` (IN `studId` VARCHAR(50), IN `newMail` VARCHAR(70), OUT `regDate` DATE)  NO SQL
BEGIN
update student 
	set emailAddress = newMail
    WHERE id_card_number = studId;
SELECT dateAdmitted from student 
	where id_card_number = studId into regDate;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updateModule` (IN `oldName` VARCHAR(100), IN `newName` VARCHAR(100), IN `numOfUnits` INT, IN `unitPrice` DOUBLE, OUT `creationDate` DATE)  BEGIN
SELECT dateCreated FROM module 
	WHERE module.name =  oldName INTO creationDate;
UPDATE `module`
SET `name`= newName,`units`= numOfUnits,`amountPerUnit`=unitPrice
	WHERE module.name =  oldName;
    

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updatePhone` (IN `studId` VARCHAR(50), IN `oldNumber` VARCHAR(20), IN `newNumber` VARCHAR(20))  BEGIN 
UPDATE `phone` 
SET `phone_number`= newNumber 
WHERE `studentId`= studId  AND `phone_number`= oldNumber; 
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updateSponsor` (IN `studId` VARCHAR(50), IN `fName` VARCHAR(50), IN `lName` VARCHAR(50), IN `addr` VARCHAR(200), IN `tel` VARCHAR(30), IN `mail` VARCHAR(100), IN `oldFirst` VARCHAR(50), IN `oldLast` VARCHAR(50), IN `oldEmail` VARCHAR(100))  NO SQL
BEGIN
UPDATE sponsor
SET  FirstName = fName,
LastName = lName, Address = addr ,
Telephone = tel, Email = mail

WHERE StudentID = studId AND FirstName =oldFirst AND LastName = oldLast AND
Email = oldEmail ;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updateStudent` (IN `oldStudentId` VARCHAR(50), IN `certIssued` VARCHAR(200), IN `active` BOOLEAN, IN `mail` VARCHAR(70), OUT `admissionDate` DATE)  BEGIN
UPDATE `student` 
SET `certificateIssued`= certIssued,
`active`=active ,`emailAddress`=mail
 WHERE oldStudentId = id_card_number;
 
 SELECT dateAdmitted FROM student 
 	WHERE id_card_number = oldStudentId INTO admissionDate;
 END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updateStudentImage` (IN `studId` VARCHAR(50), IN `img` LONGBLOB, OUT `regDate` DATE)  NO SQL
BEGIN
UPDATE student
	SET student.image = img WHERE id_card_number = studId;
    
SELECT dateAdmitted from student WHERE id_card_number = studId INTO regDate;

END$$

--
-- Functions
--
CREATE DEFINER=`root`@`localhost` FUNCTION `isPaymentComplete` (`modRegId` INT) RETURNS TINYINT(1) BEGIN
	SELECT modReg.id , 
  if( SUM( pay.amount) is not null, SUM( pay.amount), 0)  as 'Total Paid', 
  (module.units  * module.amountPerUnit) as 'Total For Module'
   
  FROM module_register as modReg
    LEFT JOIN module 
      ON module.name = modReg.ModuleName
    LEFT JOIN  payment as  pay
      ON modReg.id = pay.RegId
    WHERE modReg.id = modRegId
    GROUP BY modReg.id
    INTO @id, @totalPaid, @totalToPay;
    RETURN @totalPaid >= @totalToPay;
END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `validateAdmin` (`uName` VARCHAR(200), `pass` VARCHAR(500)) RETURNS TINYINT(1) begin 
	SELECT COUNT(*) FROM admin where username = uName AND password = uPass  into @numOfOccurrence;
    IF @numOfOccurrence=  1 THEN 
    	RETURN true;
    ELSE 
    	RETURN false;
    END IF ;
end$$

DELIMITER ;
