
-- --------------------------------------------------------

--
-- Table structure for table `moduleregisterlog`
--

CREATE TABLE `moduleregisterlog` (
  `regId` int(11) NOT NULL,
  `operationType` set('INSERT','UPDATE','DELETE') COLLATE latin1_bin DEFAULT NULL,
  `DateOfOperation` date DEFAULT NULL,
  `StudentId` varchar(50) COLLATE latin1_bin DEFAULT NULL,
  `OldModuleName` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `NewModuleName` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `OldAttendanceStatus` tinyint(1) DEFAULT NULL,
  `NewAttendanceStatus` tinyint(1) DEFAULT NULL,
  `OldBookingStatus` tinyint(1) DEFAULT NULL,
  `NewBookingStatus` int(11) DEFAULT NULL,
  `OldResult` set('PASS','FAIL') COLLATE latin1_bin DEFAULT NULL,
  `NewResult` set('PASS','FAIL') COLLATE latin1_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

--
-- Dumping data for table `moduleregisterlog`
--

INSERT INTO `moduleregisterlog` (`regId`, `operationType`, `DateOfOperation`, `StudentId`, `OldModuleName`, `NewModuleName`, `OldAttendanceStatus`, `NewAttendanceStatus`, `OldBookingStatus`, `NewBookingStatus`, `OldResult`, `NewResult`) VALUES
(4, 'INSERT', '2017-12-21', 'EMY-C32', NULL, 'Motor Controls', NULL, 0, NULL, 0, NULL, NULL),
(4, 'INSERT', '2017-12-22', 'EMY-C32', 'Motor Controls', 'Motor Controls', 0, 0, 0, 1, NULL, NULL),
(4, 'INSERT', '2017-12-22', 'EMY-C32', 'Motor Controls', 'Motor Controls', 0, 0, 1, 1, NULL, NULL),
(4, 'INSERT', '2017-12-22', 'EMY-C32', 'Motor Controls', 'Motor Controls', 0, 1, 1, 1, NULL, NULL),
(4, 'INSERT', '2017-12-22', 'EMY-C32', 'Motor Controls', 'Motor Controls', 1, 1, 1, 1, NULL, ''),
(4, 'INSERT', '2017-12-22', 'EMY-C32', 'Motor Controls', 'Motor Controls', 1, 1, 1, 1, '', 'FAIL'),
(5, 'INSERT', '2017-12-22', 'EMY-C32', NULL, 'Electrical Installation', NULL, 0, NULL, 0, NULL, NULL),
(5, 'INSERT', '2018-02-13', 'EMY-C32', 'Electrical Installation', 'Electrical Installation', 0, 0, 0, 1, NULL, NULL),
(6, 'INSERT', '2017-12-22', 'EMY-C32', NULL, 'Electrical Installation', NULL, 0, NULL, 0, NULL, NULL),
(7, 'INSERT', '2018-02-09', 'EMUAIDA', NULL, 'Motor Controls', NULL, 0, NULL, 0, NULL, NULL),
(7, 'INSERT', '2018-02-09', 'EMUAIDA', 'Motor Controls', 'Motor Controls', 0, 0, 0, 0, NULL, 'PASS'),
(8, 'INSERT', '2018-02-09', 'EMUAIDA', NULL, 'Motor Controls', NULL, 0, NULL, 0, NULL, NULL),
(9, 'INSERT', '2018-02-09', 'EMUAIDA', NULL, 'Motor Controls', NULL, 0, NULL, 0, NULL, NULL),
(9, 'INSERT', '2018-02-09', 'EMUAIDA', 'Motor Controls', 'Motor Controls', 0, 0, 0, 0, NULL, 'FAIL'),
(10, 'INSERT', '2018-02-09', 'EMUAIDA', NULL, 'Motor Controls', NULL, 0, NULL, 0, NULL, NULL),
(11, 'INSERT', '2018-02-09', 'ETY-C43', NULL, 'Motor Controls', NULL, 0, NULL, 0, NULL, NULL),
(12, 'INSERT', '2018-02-13', 'EMUAIDA', NULL, 'Electrical Load', NULL, 0, NULL, 0, NULL, NULL),
(13, 'INSERT', '2018-02-13', 'EMUAIDA', NULL, 'Electrical Panel', NULL, 0, NULL, 0, NULL, NULL),
(14, 'INSERT', '2018-02-13', 'EMY-C54', NULL, 'Electrical Panel', NULL, 0, NULL, 0, NULL, NULL),
(14, 'INSERT', '2018-02-13', 'EMY-C54', 'Electrical Panel', 'Electrical Panel', 0, 0, 0, 1, NULL, NULL),
(15, 'INSERT', '2018-02-13', 'EMY-C54', NULL, 'Knx', NULL, 0, NULL, 0, NULL, NULL),
(16, 'INSERT', '2018-02-13', 'MINUS', NULL, 'Knx', NULL, 0, NULL, 0, NULL, NULL),
(16, 'INSERT', '2018-02-13', 'MINUS', 'Knx', 'Knx', 0, 0, 0, 1, NULL, NULL),
(16, 'INSERT', '2018-02-13', 'MINUS', 'Knx', 'Knx', 0, 1, 1, 1, NULL, NULL),
(16, 'INSERT', '2018-02-13', 'MINUS', 'Knx', 'Knx', 1, 1, 1, 1, NULL, 'FAIL'),
(17, 'INSERT', '2018-02-13', 'NAME', NULL, 'Knx', NULL, 0, NULL, 0, NULL, NULL),
(17, 'INSERT', '2018-02-13', 'NAME', 'Knx', 'Knx', 0, 0, 0, 1, NULL, NULL),
(18, 'INSERT', '2018-02-13', 'PIO2828', NULL, 'Electrical Load', NULL, 0, NULL, 0, NULL, NULL),
(19, 'INSERT', '2018-02-13', 'EMY-C4', NULL, 'Knx', NULL, 0, NULL, 0, NULL, NULL),
(20, 'INSERT', '2018-02-13', 'EMY-C4', NULL, 'Electrical Panel', NULL, 0, NULL, 0, NULL, NULL);
