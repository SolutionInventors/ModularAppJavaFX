
-- --------------------------------------------------------

--
-- Table structure for table `certificate`
--

CREATE TABLE `certificate` (
  `DateCreated` date DEFAULT NULL,
  `Name` varchar(200) COLLATE latin1_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

--
-- Dumping data for table `certificate`
--

INSERT INTO `certificate` (`DateCreated`, `Name`) VALUES
('2017-12-19', 'Electromecnics'),
('2017-12-19', 'Modular Electrotechnics'),
('2017-12-19', 'Modular Mecatronics'),
('2017-12-22', 'Junk'),
('2017-12-22', 'Name');

--
-- Triggers `certificate`
--
DELIMITER $$
CREATE TRIGGER `certificateDeleteTrigger` AFTER DELETE ON `certificate` FOR EACH ROW BEGIN
	INSERT INTO CertificateLog( dateOfOperation, operationType, oldCertificateName)
    VALUES( now(), 'DELETE', old.name);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `certificateInsertTrigger` AFTER INSERT ON `certificate` FOR EACH ROW BEGIN
	INSERT INTO CertificateLog( dateOfOperation, operationType, oldCertificateName, newCertificateName)
    VALUES( now(), 'INSERT', NULL , new.name);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `certificateUpdateTrigger` AFTER UPDATE ON `certificate` FOR EACH ROW BEGIN
	INSERT INTO CertificateLog( dateOfOperation, operationType, oldCertificateName, newCertificateName)
    VALUES( now(), 'UPDATE', old.name, new.name);
END
$$
DELIMITER ;
