
-- --------------------------------------------------------

--
-- Table structure for table `aspiringstudent`
--

CREATE TABLE `aspiringstudent` (
  `ID` int(255) NOT NULL,
  `Title` varchar(20) COLLATE latin1_bin NOT NULL,
  `PermanentAddress` varchar(159) COLLATE latin1_bin NOT NULL,
  `CurrentAddress` varchar(50) COLLATE latin1_bin NOT NULL,
  `StateOfOrigin` varchar(200) COLLATE latin1_bin NOT NULL,
  `Country` varchar(200) COLLATE latin1_bin NOT NULL,
  `Gender` set('MALE','FEMALE') COLLATE latin1_bin NOT NULL,
  `DateOfBirth` date NOT NULL,
  `PlaceOfBirth` varchar(30) COLLATE latin1_bin NOT NULL,
  `Religion` varchar(50) COLLATE latin1_bin NOT NULL,
  `FirstName` varchar(50) COLLATE latin1_bin NOT NULL,
  `LastName` varchar(50) COLLATE latin1_bin NOT NULL,
  `EmailAddress` varchar(255) COLLATE latin1_bin NOT NULL,
  `YearsExperience` int(2) NOT NULL,
  `HighestQualification` varchar(100) COLLATE latin1_bin NOT NULL,
  `HighestQualificationCourse` varchar(60) COLLATE latin1_bin NOT NULL,
  `CurrentWorkplace` varchar(100) COLLATE latin1_bin NOT NULL,
  `LastInstituteAttended` varchar(30) COLLATE latin1_bin NOT NULL,
  `Image` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;
