
-- --------------------------------------------------------

--
-- Table structure for table `modular_class_log`
--

CREATE TABLE `modular_class_log` (
  `OldName` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `NewName` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `DateOfOperation` date NOT NULL,
  `OperationType` set('INSERT','UPDATE','DELETE') COLLATE latin1_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

--
-- Dumping data for table `modular_class_log`
--

INSERT INTO `modular_class_log` (`OldName`, `NewName`, `DateOfOperation`, `OperationType`) VALUES
(NULL, 'Stream 1', '2017-12-19', 'INSERT'),
(NULL, 'Stream 1', '2017-12-19', 'INSERT'),
('Stream 4', 'Stream 2', '2017-12-19', 'UPDATE'),
('Stream 1', 'Stream 4', '2017-12-19', 'UPDATE');
