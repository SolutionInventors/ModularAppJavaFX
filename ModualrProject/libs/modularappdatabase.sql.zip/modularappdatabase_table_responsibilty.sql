
-- --------------------------------------------------------

--
-- Table structure for table `responsibilty`
--

CREATE TABLE `responsibilty` (
  `id` int(11) NOT NULL,
  `experienceId` int(11) NOT NULL,
  `Duty` varchar(1000) COLLATE latin1_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

--
-- Dumping data for table `responsibilty`
--

INSERT INTO `responsibilty` (`id`, `experienceId`, `Duty`) VALUES
(13, 12, 'REpair'),
(14, 12, 'Overhaul'),
(15, 13, 'Manage Projects'),
(16, 14, 'Repair Of Alternator'),
(17, 14, 'Installation Of Gensets'),
(18, 15, 'Solving Math'),
(19, 15, 'Reapair Of Installation Equipments');
