
-- --------------------------------------------------------

--
-- Table structure for table `modular_class`
--

CREATE TABLE `modular_class` (
  `name` varchar(30) COLLATE latin1_bin NOT NULL,
  `dateCreated` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

--
-- Dumping data for table `modular_class`
--

INSERT INTO `modular_class` (`name`, `dateCreated`) VALUES
('Stream 1', '2017-12-19'),
('Stream 2', '2017-12-19');

--
-- Triggers `modular_class`
--
DELIMITER $$
CREATE TRIGGER `ClassInsertTrigger` AFTER INSERT ON `modular_class` FOR EACH ROW BEGIN
INSERT INTO `modularclasslog`
(`OldName`, `NewName`, `dateofoperation`, `OperationType`) 

VALUES (NULL ,new.name  ,now() , 'INSERT');
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `ClassUpdateTrigger` AFTER UPDATE ON `modular_class` FOR EACH ROW BEGIN
INSERT INTO `modularclasslog`
(`OldName`, `NewName`, `dateofoperation`, `OperationType`) 
VALUES (old.name ,new.name  ,now() , 'UPDATE');
END
$$
DELIMITER ;
