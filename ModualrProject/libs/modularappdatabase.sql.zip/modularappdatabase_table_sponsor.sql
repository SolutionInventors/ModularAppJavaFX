
-- --------------------------------------------------------

--
-- Table structure for table `sponsor`
--

CREATE TABLE `sponsor` (
  `StudentID` varchar(50) COLLATE latin1_bin NOT NULL,
  `FirstName` varchar(30) COLLATE latin1_bin NOT NULL,
  `LastName` varchar(30) COLLATE latin1_bin NOT NULL,
  `Address` varchar(500) COLLATE latin1_bin NOT NULL,
  `Telephone` varchar(30) COLLATE latin1_bin NOT NULL,
  `Email` varchar(254) COLLATE latin1_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

--
-- Dumping data for table `sponsor`
--

INSERT INTO `sponsor` (`StudentID`, `FirstName`, `LastName`, `Address`, `Telephone`, `Email`) VALUES
('EMY-C32', 'John', 'Kennedy', 'currAddr', '39209320', 'email.com');
