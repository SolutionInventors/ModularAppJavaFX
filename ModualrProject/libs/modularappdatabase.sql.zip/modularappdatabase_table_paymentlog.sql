
-- --------------------------------------------------------

--
-- Table structure for table `paymentlog`
--

CREATE TABLE `paymentlog` (
  `RegId` int(11) NOT NULL,
  `Dateofoperation` date DEFAULT NULL,
  `StudentID` varchar(50) COLLATE latin1_bin NOT NULL,
  `ModuleName` varchar(200) COLLATE latin1_bin NOT NULL,
  `OperationType` varchar(30) COLLATE latin1_bin DEFAULT NULL,
  `BankName` varchar(50) COLLATE latin1_bin NOT NULL,
  `Amount` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;
