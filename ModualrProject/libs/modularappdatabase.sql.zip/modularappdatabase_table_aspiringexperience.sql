
-- --------------------------------------------------------

--
-- Table structure for table `aspiringexperience`
--

CREATE TABLE `aspiringexperience` (
  `ID` int(255) NOT NULL,
  `AspiringStudID` int(255) NOT NULL,
  `BeignDate` date NOT NULL,
  `EndDate` date NOT NULL,
  `JobTitle` varchar(50) COLLATE latin1_bin NOT NULL,
  `Employer` varchar(90) COLLATE latin1_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;
