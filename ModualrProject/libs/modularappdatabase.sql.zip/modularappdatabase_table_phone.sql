
-- --------------------------------------------------------

--
-- Table structure for table `phone`
--

CREATE TABLE `phone` (
  `StudentId` varchar(50) COLLATE latin1_bin DEFAULT NULL,
  `phone_number` varchar(20) COLLATE latin1_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

--
-- Dumping data for table `phone`
--

INSERT INTO `phone` (`StudentId`, `phone_number`) VALUES
('EMUAIDA', '039019301'),
('EMY-C1', '90239209320'),
('EMY-C32', '3920920'),
('EMY-C32', '930239029'),
('EMY-C4', '309209390239'),
('EMY-C54', '08123232232'),
('ETY-C3', '320929320'),
('MINUS', '39203920'),
('NAME', '02302392032930'),
('PIO2828', '4839439');
