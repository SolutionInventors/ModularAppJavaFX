
-- --------------------------------------------------------

--
-- Table structure for table `aspiringstudenteducation`
--

CREATE TABLE `aspiringstudenteducation` (
  `AspiringStudentID` int(255) NOT NULL,
  `BegunDate` date NOT NULL,
  `EndDate` date NOT NULL,
  `CourseRead` varchar(150) COLLATE latin1_bin NOT NULL,
  `Institution` varchar(150) COLLATE latin1_bin NOT NULL,
  `QualificationName` varchar(100) COLLATE latin1_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;
