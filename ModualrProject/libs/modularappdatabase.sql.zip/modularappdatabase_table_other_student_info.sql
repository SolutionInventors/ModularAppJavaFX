
-- --------------------------------------------------------

--
-- Table structure for table `other_student_info`
--

CREATE TABLE `other_student_info` (
  `StudentID` varchar(50) COLLATE latin1_bin NOT NULL,
  `HighestQualification` varchar(50) COLLATE latin1_bin NOT NULL,
  `CurrentWorkPlace` varchar(100) COLLATE latin1_bin NOT NULL,
  `YearsWorkingExperience` int(11) NOT NULL,
  `LastCourseRead` varchar(50) COLLATE latin1_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;
