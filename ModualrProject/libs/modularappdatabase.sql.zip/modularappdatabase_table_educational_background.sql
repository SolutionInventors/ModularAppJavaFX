
-- --------------------------------------------------------

--
-- Table structure for table `educational_background`
--

CREATE TABLE `educational_background` (
  `StudentID` varchar(50) COLLATE latin1_bin NOT NULL,
  `BeginDate` date NOT NULL,
  `EndDate` date NOT NULL,
  `Institution` varchar(200) COLLATE latin1_bin NOT NULL,
  `CourseRead` varchar(200) COLLATE latin1_bin NOT NULL,
  `QualificationName` varchar(200) COLLATE latin1_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

--
-- Dumping data for table `educational_background`
--

INSERT INTO `educational_background` (`StudentID`, `BeginDate`, `EndDate`, `Institution`, `CourseRead`, `QualificationName`) VALUES
('EMY-C32', '2010-01-10', '2016-01-10', 'Iit', 'Bsc', 'Bsc'),
('EMY-C32', '2010-01-10', '2016-01-10', 'Peeny', 'O-lneve', 'O-level'),
('EMUAIDA', '2010-01-10', '2016-01-10', 'Ii', 'Technical Studies', 'Bsc'),
('EMY-C1', '2010-01-10', '2016-01-10', 'Penny', 'Math', 'O\'level'),
('EMY-C54', '2010-01-10', '2016-01-10', 'Iit', 'Automation', 'Bsc'),
('EMY-C54', '2010-01-10', '2016-01-10', 'Penny', 'O Level', 'Bsc'),
('NAME', '2010-01-10', '2016-01-10', 'Iit', 'Math', 'Bsc'),
('ETY-C3', '2010-01-10', '2016-01-10', 'Iit', 'Name', 'Bsc'),
('EMY-C4', '2010-01-10', '2016-01-10', 'Unilag', 'Bsc', 'Bsc'),
('MINUS', '2010-01-10', '2016-01-10', 'Iit', 'Name', 'Bsc'),
('PIO2828', '2010-01-10', '2016-01-10', 'Iit', 'Bsc', 'Bsc');
