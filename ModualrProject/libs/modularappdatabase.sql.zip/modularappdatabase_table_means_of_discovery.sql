
-- --------------------------------------------------------

--
-- Table structure for table `means_of_discovery`
--

CREATE TABLE `means_of_discovery` (
  `StudentID` varchar(50) COLLATE latin1_bin NOT NULL,
  `Means` varchar(300) COLLATE latin1_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

--
-- Dumping data for table `means_of_discovery`
--

INSERT INTO `means_of_discovery` (`StudentID`, `Means`) VALUES
('EMUAIDA', 'Facebook'),
('EMY-C1', 'Facebook'),
('EMY-C32', 'Facebook'),
('EMY-C32', 'News'),
('EMY-C32', 'Twitter'),
('EMY-C4', 'Whatsapp'),
('EMY-C54', 'Facebook'),
('EMY-C54', 'News'),
('EMY-C54', 'Newspaper'),
('ETY-C3', 'Facbook'),
('MINUS', 'Youtube'),
('NAME', 'Facbook'),
('PIO2828', 'Facebook');
