
--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`username`) USING BTREE,
  ADD UNIQUE KEY `Email` (`Email`),
  ADD KEY `Email_Index` (`username`,`password`) USING BTREE;

--
-- Indexes for table `aspiringexperience`
--
ALTER TABLE `aspiringexperience`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `aspiring_stud_link` (`AspiringStudID`);

--
-- Indexes for table `aspiringjobresponsibility`
--
ALTER TABLE `aspiringjobresponsibility`
  ADD KEY `expLink` (`AspiringExpId`);

--
-- Indexes for table `aspiringmeans`
--
ALTER TABLE `aspiringmeans`
  ADD KEY `aspMeansLink` (`AspiringID`);

--
-- Indexes for table `aspiringstudent`
--
ALTER TABLE `aspiringstudent`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `aspiringstudenteducation`
--
ALTER TABLE `aspiringstudenteducation`
  ADD KEY `aspEduLink` (`AspiringStudentID`);

--
-- Indexes for table `aspiringstudentphone`
--
ALTER TABLE `aspiringstudentphone`
  ADD KEY `sudLink` (`AspiringID`);

--
-- Indexes for table `biodata`
--
ALTER TABLE `biodata`
  ADD UNIQUE KEY `studentId` (`studentId`);
ALTER TABLE `biodata` ADD FULLTEXT KEY `name_index` (`FirstName`,`LastName`);

--
-- Indexes for table `certificate`
--
ALTER TABLE `certificate`
  ADD PRIMARY KEY (`Name`),
  ADD KEY `DateCreated` (`DateCreated`,`Name`) USING BTREE;

--
-- Indexes for table `certificatelog`
--
ALTER TABLE `certificatelog`
  ADD KEY `log_date_index` (`dateOfOperation`,`newCertificateName`,`oldCertificateName`,`operationType`) USING BTREE;
ALTER TABLE `certificatelog` ADD FULLTEXT KEY `log_type_index` (`operationType`);

--
-- Indexes for table `certificateregister`
--
ALTER TABLE `certificateregister`
  ADD KEY `moduleLink` (`moduleName`,`certificateName`) USING BTREE,
  ADD KEY `certModuleKey` (`certificateName`,`moduleName`) USING BTREE;

--
-- Indexes for table `certificateregisterlog`
--
ALTER TABLE `certificateregisterlog`
  ADD KEY `log_type_index` (`operationType`),
  ADD KEY `date_index` (`DateOfOperation`,`operationType`,`NewCertificateName`,`NewModuleName`,`OldModuleName`,`OldCertificateName`) USING BTREE;

--
-- Indexes for table `educational_background`
--
ALTER TABLE `educational_background`
  ADD KEY `StudentID` (`StudentID`);

--
-- Indexes for table `means_of_discovery`
--
ALTER TABLE `means_of_discovery`
  ADD KEY `studentMeansLink` (`StudentID`,`Means`) USING BTREE;

--
-- Indexes for table `modular_class`
--
ALTER TABLE `modular_class`
  ADD PRIMARY KEY (`name`),
  ADD KEY `dateCreated` (`dateCreated`);

--
-- Indexes for table `modular_class_log`
--
ALTER TABLE `modular_class_log`
  ADD KEY `DateOfOperation` (`DateOfOperation`,`OperationType`,`NewName`,`OldName`) USING BTREE;

--
-- Indexes for table `module`
--
ALTER TABLE `module`
  ADD PRIMARY KEY (`name`),
  ADD KEY `date_index` (`amountPerUnit`) USING BTREE;

--
-- Indexes for table `modulelog`
--
ALTER TABLE `modulelog`
  ADD KEY `dateOfOperation` (`dateOfOperation`,`operationType`,`newModuleName`,`oldModuleName`) USING BTREE;

--
-- Indexes for table `moduleregisterlog`
--
ALTER TABLE `moduleregisterlog`
  ADD KEY `regId` (`regId`,`StudentId`,`operationType`,`DateOfOperation`,`OldModuleName`,`NewModuleName`,`OldAttendanceStatus`,`NewAttendanceStatus`,`OldBookingStatus`,`NewBookingStatus`,`OldResult`,`NewResult`) USING BTREE;

--
-- Indexes for table `module_register`
--
ALTER TABLE `module_register`
  ADD PRIMARY KEY (`id`),
  ADD KEY `StudentLink2` (`StudentId`),
  ADD KEY `mod_student_index` (`ModuleName`,`StudentId`) USING BTREE;

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tbl_link` (`RegId`,`dateOfPayment`,`bankName`(4),`tellerNumber`,`amount`) USING BTREE;

--
-- Indexes for table `paymentlog`
--
ALTER TABLE `paymentlog`
  ADD KEY `StudentID` (`StudentID`,`RegId`) USING BTREE,
  ADD KEY `bankName_index` (`BankName`(5),`Dateofoperation`);

--
-- Indexes for table `phone`
--
ALTER TABLE `phone`
  ADD UNIQUE KEY `student_id` (`StudentId`,`phone_number`);

--
-- Indexes for table `professional_experience`
--
ALTER TABLE `professional_experience`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `StudentId` (`StudentId`,`Employer`,`Job Title`,`StartDate`,`EndDate`);

--
-- Indexes for table `resources`
--
ALTER TABLE `resources`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `responsibilty`
--
ALTER TABLE `responsibilty`
  ADD PRIMARY KEY (`id`),
  ADD KEY `experienceId` (`experienceId`);

--
-- Indexes for table `sponsor`
--
ALTER TABLE `sponsor`
  ADD UNIQUE KEY `StudentID` (`StudentID`,`FirstName`,`LastName`,`Email`) USING BTREE,
  ADD KEY `sponsor_mail` (`Email`);
ALTER TABLE `sponsor` ADD FULLTEXT KEY `sponsor_name_index` (`FirstName`,`LastName`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id_card_number`),
  ADD KEY `student_certificate_link` (`certificateIssued`),
  ADD KEY `student_mail` (`id_card_number`,`emailAddress`,`dateAdmitted`) USING BTREE,
  ADD KEY `student_class` (`className`) USING BTREE;

--
-- Indexes for table `studentlog`
--
ALTER TABLE `studentlog`
  ADD KEY `operationType` (`operationType`,`dateOfOperation`,`NewID`,`OldID`,`PrevCertificateIssued`,`NewCertificateIssued`,`PrevActiveStatus`,`NewActiveStatus`,`PrevEmail`,`NewEmail`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aspiringexperience`
--
ALTER TABLE `aspiringexperience`
  MODIFY `ID` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `aspiringstudent`
--
ALTER TABLE `aspiringstudent`
  MODIFY `ID` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `module_register`
--
ALTER TABLE `module_register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `professional_experience`
--
ALTER TABLE `professional_experience`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `resources`
--
ALTER TABLE `resources`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `responsibilty`
--
ALTER TABLE `responsibilty`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `aspiringexperience`
--
ALTER TABLE `aspiringexperience`
  ADD CONSTRAINT `aspiring_stud_link` FOREIGN KEY (`AspiringStudID`) REFERENCES `aspiringstudent` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `aspiringjobresponsibility`
--
ALTER TABLE `aspiringjobresponsibility`
  ADD CONSTRAINT `expLink` FOREIGN KEY (`AspiringExpId`) REFERENCES `aspiringexperience` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `aspiringmeans`
--
ALTER TABLE `aspiringmeans`
  ADD CONSTRAINT `aspMeansLink` FOREIGN KEY (`AspiringID`) REFERENCES `aspiringstudent` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `aspiringstudenteducation`
--
ALTER TABLE `aspiringstudenteducation`
  ADD CONSTRAINT `aspEduLink` FOREIGN KEY (`AspiringStudentID`) REFERENCES `aspiringstudent` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `aspiringstudentphone`
--
ALTER TABLE `aspiringstudentphone`
  ADD CONSTRAINT `sudLink` FOREIGN KEY (`AspiringID`) REFERENCES `aspiringstudent` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `biodata`
--
ALTER TABLE `biodata`
  ADD CONSTRAINT `studentID_link` FOREIGN KEY (`studentId`) REFERENCES `student` (`id_card_number`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `certificateregister`
--
ALTER TABLE `certificateregister`
  ADD CONSTRAINT `certificateLink` FOREIGN KEY (`certificateName`) REFERENCES `certificate` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `moduleLink` FOREIGN KEY (`moduleName`) REFERENCES `module` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `educational_background`
--
ALTER TABLE `educational_background`
  ADD CONSTRAINT `LinktoStudent` FOREIGN KEY (`StudentID`) REFERENCES `student` (`id_card_number`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `means_of_discovery`
--
ALTER TABLE `means_of_discovery`
  ADD CONSTRAINT `studentMeansLink` FOREIGN KEY (`StudentID`) REFERENCES `student` (`id_card_number`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `module_register`
--
ALTER TABLE `module_register`
  ADD CONSTRAINT `ModuleLink3` FOREIGN KEY (`ModuleName`) REFERENCES `module` (`name`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `StudentLink2` FOREIGN KEY (`StudentId`) REFERENCES `student` (`id_card_number`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `RegLink` FOREIGN KEY (`RegId`) REFERENCES `module_register` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Constraints for table `phone`
--
ALTER TABLE `phone`
  ADD CONSTRAINT `phoneLink` FOREIGN KEY (`StudentId`) REFERENCES `student` (`id_card_number`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `professional_experience`
--
ALTER TABLE `professional_experience`
  ADD CONSTRAINT `StudentLink` FOREIGN KEY (`StudentId`) REFERENCES `student` (`id_card_number`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `responsibilty`
--
ALTER TABLE `responsibilty`
  ADD CONSTRAINT `responsibilty_ibfk_1` FOREIGN KEY (`experienceId`) REFERENCES `professional_experience` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sponsor`
--
ALTER TABLE `sponsor`
  ADD CONSTRAINT `financeLink` FOREIGN KEY (`StudentID`) REFERENCES `student` (`id_card_number`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `student_certificate_link` FOREIGN KEY (`certificateIssued`) REFERENCES `certificate` (`name`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `student_ibfk_1` FOREIGN KEY (`className`) REFERENCES `modular_class` (`name`) ON DELETE NO ACTION ON UPDATE CASCADE;
