
-- --------------------------------------------------------

--
-- Table structure for table `certificateregister`
--

CREATE TABLE `certificateregister` (
  `certificateName` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `moduleName` varchar(100) COLLATE latin1_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

--
-- Dumping data for table `certificateregister`
--

INSERT INTO `certificateregister` (`certificateName`, `moduleName`) VALUES
('Modular Mecatronics', 'Electrical Installation'),
('Name', 'Electrical Installation'),
('Electromecnics', 'Electrical Panel'),
('Electromecnics', 'Mechanical Mesurements and fitting'),
('Name', 'Mechanical Mesurements and fitting'),
('Modular Mecatronics', 'Motor Controls'),
('Electromecnics', 'Physics'),
('Name', 'Physics'),
('Modular Mecatronics', 'Power electronics'),
('Name', 'Power electronics'),
('Modular Mecatronics', 'Technical Drawing');

--
-- Triggers `certificateregister`
--
DELIMITER $$
CREATE TRIGGER `certificateRegisterDeleteTrigger` AFTER DELETE ON `certificateregister` FOR EACH ROW BEGIN
INSERT INTO `certificateregisterlog`(`DateOfOperation`, `operationType`, `NewModuleName`, `OldModuleName`, `NewCertificateName`, `OldCertificateName`)
VALUES (now(),'DELETE',NULL,
        old.ModuleName,NULL, old.certificateName);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `certificateRegisterInsertTrigger` AFTER INSERT ON `certificateregister` FOR EACH ROW BEGIN
INSERT INTO `certificateregisterlog`(`DateOfOperation`, `operationType`, `NewModuleName`, `OldModuleName`, `NewCertificateName`, `OldCertificateName`)
VALUES (now(),'INSERT',new.ModuleName,NULL,new.CertificateName,NULL);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `certificateRegisterUpdateTrigger` AFTER UPDATE ON `certificateregister` FOR EACH ROW BEGIN
INSERT INTO `certificateregisterlog`(`DateOfOperation`, `operationType`, `NewModuleName`, `OldModuleName`, `NewCertificateName`, `OldCertificateName`)
VALUES (now(),'UPDATE',new.ModuleName,old.ModuleName,
        new.CertificateName, old.certificateName);
END
$$
DELIMITER ;
