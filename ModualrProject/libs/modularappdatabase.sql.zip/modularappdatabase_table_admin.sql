
-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(200) COLLATE latin1_bin NOT NULL,
  `Email` varchar(256) COLLATE latin1_bin NOT NULL,
  `password` varchar(500) COLLATE latin1_bin NOT NULL,
  `AccessType` set('SUPER','READ','WRITE','READ_AND_WRITE') COLLATE latin1_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `Email`, `password`, `AccessType`) VALUES
('Chdosahcahdp', 'cdcda', '0fceea1d587d99c040dde23d2b19331867a66f5deda3b01a8e0de28382496eb2e627178d2663caa8cd430e31848b5ec02abf96f6e52e50a1b7b9e4efbc136a3deIEPtBlWHHvxpsWdHagPpAzGhYHyQovMcZAcXLjfesFARhPCGYBmXagJcflXJYdswXbHrBdAwquupfFagnlFclgSvAbUCeuTfeje', ''),
('Chid', 'cwne', 'f63b6fc8fc970471ddcd996bdca97d0b0577ddb2264fd41b75bc7523e7ba6af52c5e26c6ef89d5f815a70e1a2148753ee956bc6c04d39279356d5c46c76fde6bfmoOqzwogshEPDXpyCtIVsrdfpzMmgSTdfyhbgDcwGgIyZOxxVbVlkmBMJFvNvOelHXJrfOQUCoZZvqTgXWChJRKSgAwwGNfTGld', 'READ_AND_WRITE'),
('Chidi', 'chidioguejiofor@gmail.com', '0cf1d7f6d1100bb8f06ff9dbeb071c936fe636f37adfaedbd6d73dd7cd919d7f8c2ef51fbb373ab19b8631588b74cf70d84347e5dfecf6fd168ee395b3e7aab6hODtmFDGmCfztixmGghjRghknVLVsitYghdgJcOHoDMklYlHasvgjbpcakAiXXToQFBykyfjlUTZZzddfMjYcbsuyavueKOIpByB', 'SUPER'),
('Fred101', 'chidi@gmail.com', 'b6924b180616ac9af1c13f8937bb535caf6080e6e6ab1010ba08a2d79bf252391eddfbd7771bdec499d9a3551ad18f4344bd10b7c1bd07601cad3f9bc9dfb434vbzbuAbOhlHMgZqgiyxxqYyhYzgwGxIORaHVpxdyVmvJrcKUHiZfQhDBudfCIcrvSkwawlggrKDVZgZZdfLbnvYhwgMgOdociyfg', ''),
('Fred202', 'nameMail.com', '01b3fa985c05d7cda71aa39839fc25e0f1da1803f2aa1d921675dbda38efda6a3b1eb2aa2e592300039a5d35dc216495cf63856c9adc43897811a83e065a2a3bWhnYyGTjJzBTGhnopXEokXncRLadamnLcFYBwhbObrSfepHZmmSkudEOjznNAhNJVbUKUlMvgxcfcbrCjrSOLlYmylwyfKmDsslr', ''),
('Name', 'dns;', '8474f1a9610fcafae66676c9853b34c5b08ab318445b60ae035de3e6949af035f30c491266f8a31f36890611894e99eb35cb9cf53133fd6aa6fd44b2ce7c315fkiMTWclNCLDKAXpoLHhgncoUqeLfFrTeamcswFOtcFWeTHxoWhjcStmEjNKbCICEdOrifnyQBmQTAhTgwkOsudgvJcGHIcJxfWaN', ''),
('Ncndjnadcna', 'cdcsca', '22a79eb3a0081a8ff1cc98a5e3c29ba12e859a252a7f9769aaa01a8ae00927076efd8a18296c16069caef860387fb46ee6bbdd9e3965305f404ad7595b1e8ccdJopcTurhKoyDggldZVgslKBrdLdnxlDvjhuLFtxTdVlntfYWYnLAivFOCkwvjhHWPtyZmIYWLghGkKpAhePvwnzcgTnVocAwhckv', ''),
('NewAdmin', 'emsia', '05f5d5188aecdb802c486b58251e32afffc31710800998f838acde6026257f10ecdf76281ecf60d37c0da0f213331103ecc23c887b6977adefb1757bd456268eadAuWbQipBaewbrTkzxMxPiAjpQMfArIZTnQzrfOdSZNSQlTHMcShJyHyEkOqRtbcZZZWCjmJpdYZytxWqHobMhtptOwZpTHpkGZ', ''),
('cdsacdc', 'cdsc', '5fd16099b63c5eac6fd92911aea030e8dc1abcdbda59cb32b1880d1e1f9e3da86a4b17de83698290d227ca0d8df7fa856cbe61ce8970341f7babc21f72a30f6dWPUbyzeMBlcDfjVSWXeGeLxHObKczMdcyvhHKEbFeuiBYgjbdxvBdQcwtRzfQnBtLgfUgdeRuwdWEdDixIgBwuHCpojsrJoLhdDt', '');
